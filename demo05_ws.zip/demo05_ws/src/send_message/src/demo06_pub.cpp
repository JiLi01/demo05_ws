/*
    需求: 循环发布人的信息

*/

#include "ros/ros.h"
#include "message_plus_send/Person.h"

int main(int argc, char *argv[])
{
    ROS_INFO("Here is the publisher B.");
    
    //1.Initialize ROS node
    ros::init(argc,argv,"talker_person_two");

    //2.Create ROS node handle
    ros::NodeHandle nh;

    //3.Create publisher
    ros::Publisher pub = nh.advertise<message_plus_send::Person>("chatter_person_two",10);

    //4.Publish the message
    message_plus_send::Person person;
    person.name = "Lea";
    person.age = 30;
    person.height = 1.65;

    ros::Rate rate(1); //Send the message once a time
    while (ros::ok())
    {
        pub.publish(person);
        person.age += 1;
        ROS_INFO("My name is:%s,my age is %d, I am %.2fm tall", person.name.c_str(), person.age, person.height);

        rate.sleep();
        ros::spinOnce();
    }



    return 0;
}
