#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/jiaxin/demo05_ws/src/message_plus_send/.obj-x86_64-linux-gnu/devel:$CMAKE_PREFIX_PATH"
export PWD='/home/jiaxin/demo05_ws/src/message_plus_send/.obj-x86_64-linux-gnu'
export ROSLISP_PACKAGE_DIRECTORIES='/home/jiaxin/demo05_ws/src/message_plus_send/.obj-x86_64-linux-gnu/devel/share/common-lisp'
export ROS_PACKAGE_PATH="/home/jiaxin/demo05_ws/src/message_plus_send:$ROS_PACKAGE_PATH"