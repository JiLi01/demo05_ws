# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/jiaxin/demo05_ws/src/message_plus_send/.obj-x86_64-linux-gnu/devel/include".split(';') if "/home/jiaxin/demo05_ws/src/message_plus_send/.obj-x86_64-linux-gnu/devel/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;std_msgs;message_runtime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "message_plus_send"
PROJECT_SPACE_DIR = "/home/jiaxin/demo05_ws/src/message_plus_send/.obj-x86_64-linux-gnu/devel"
PROJECT_VERSION = "0.0.0"
