# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/jiaxin/demo05_ws/src/message_plus_send/msg/Person.msg"
services_str = ""
pkg_name = "message_plus_send"
dependencies_str = "std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "message_plus_send;/home/jiaxin/demo05_ws/src/message_plus_send/msg;std_msgs;/opt/ros/noetic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python3"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/noetic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
